package com.data_structures_and_algorithms_CSC301.Assignments.Assignment_2;

public class Constants {
    // Colors
    public static final String ANSI_RED = "\u001B[31m"; // Alerts
    public static final String ANSI_GREEN = "\u001B[32m"; // Static information
    public static final String ANSI_BLUE = "\u001B[34m"; // Collections
    public static final String ANSI_YELLOW = "\u001b[33m"; // Collections
    public static final String ANSI_CYAN = "\u001b[36m"; // Collections
    public static final String ANSI_RESET = "\u001B[0m";
}
